#include <gtk/gtk.h>


void
on_bajtree_row_activated               (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_bafrf_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bafsu_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bafmo_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bafaj_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bafre_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bajgf_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bajgh_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bajaj_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bafret_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bajgh_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bajaff_clicked                      (GtkButton       *objet,
                                        gpointer         user_data);

void
on_bajgh_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bmodaff_clicked                     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_bmobr_clicked                       (GtkButton       *objet,
                                        gpointer         user_data);

void
on_bmobr_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficher_supprimer_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_modifier_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_ajouter_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_rechercher_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_elec_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retour__modifier__clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_ajouter__modifier__clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_alerte_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_oi_clicked                          (GtkToggleButton       *togglebutton,
                                        gpointer         user_data);

void
on_no_clicked                          (GtkToggleButton       *togglebutton,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_cherch_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_nouv_modifier_election_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_newmodifier_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_conf_alerte_clicked                 (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_con_alerte_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_ajouterObs_clicked                 (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_modifierObs_clicked                (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_suppObs_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercheobs_clicked               (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_nombreTotal_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_triData_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refreshData_clicked                (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_radiobuttonHA_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonFA_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_addObs_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourAjObs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deleteObs_clicked                  (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_retourDelObs_clicked               (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_retourEditObs_clicked              (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_rechercheObs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonHE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonFE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_saveChanges_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_closePopup_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourFiltrerData_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercheNom_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
