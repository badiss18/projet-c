#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"election.h"
enum{
	EID,
	EJOUR,
	EMOIS,
	EANNEE,
	ENOMBRE_HABITANTS,
	ENOMBRE_DE_CONSEILLER,
	EMUNICIPALITE,
	COLUMNS,
};

int ajouter(char *file,ele elc)
{

FILE * f=fopen("election.txt","a");
	if(f!=NULL)
	{

		fprintf(f,"%d %d %d %d %s %s %s \n",elc.id,elc.jour,elc.mois,elc.annee,elc.nombre_habitants,elc.nombre_de_conseiller,elc.municipalite);
fclose(f);//f retour de la fonction fopen
       return 1;
    }
    else return 0;

}

int verifier(char *file,int id )
{
	ele elc;
	FILE*f;
	f=fopen("election.txt","r");
	if(f!=NULL)
{
while(fscanf(f,"%d %d %d %d %s %s %s \n",&elc.id,&elc.jour,&elc.mois,&elc.annee,elc.nombre_habitants,elc.nombre_de_conseiller,elc.municipalite)!=EOF)
        {
            if(id == elc.id)
		{
			return 1;
		}
		}
			return 0;
		fclose(f);
}
}

int modifier( char * file , int id , ele nv_elec )
{
    int tr=0;
    ele elc;
    FILE * f=fopen("election.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %d %d %s %s %s \n",&elc.id,&elc.jour,&elc.mois,&elc.annee,elc.nombre_habitants,elc.nombre_de_conseiller,elc.municipalite)!=EOF)
        {
            if(id == elc.id)
            {
       fprintf(f2,"%d %d %d %d %s %s %s\n",  nv_elec.id,nv_elec.jour,nv_elec.mois,nv_elec.annee,nv_elec.nombre_habitants,nv_elec.nombre_de_conseiller,nv_elec.municipalite);
                tr=1;
            }
            else
                fprintf(f2,"%d %d %d %d %s %s %s \n",elc.id,elc.jour,elc.mois,elc.annee,elc.nombre_habitants,elc.nombre_de_conseiller,elc.municipalite);

        }
    }
    fclose(f);
    fclose(f2);
    remove("election.txt");
   rename("nouv.txt", "election.txt");
    return tr;

}

int supprimer(char * file , int id)
{    

    int tr=0;
    ele elc;
    FILE * f=fopen("election.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %d %d %s %s %s \n",&elc.id,&elc.jour,&elc.mois,&elc.annee,elc.nombre_habitants,elc.nombre_de_conseiller,elc.municipalite)!=EOF)
        {
            if(elc.id==id)
                tr=1;
            else
                fprintf(f2,"%d %d %d %d %s %s %s \n",elc.id,elc.jour,elc.mois,elc.annee,elc.nombre_habitants,elc.nombre_de_conseiller,elc.municipalite);
        }
    }
    fclose(f);
    fclose(f2);
    remove("election.txt");
    rename("nouv.txt", "election.txt");
    return tr;

}
void chercher(int id ,GtkWidget *liste)

{
int b;
ele elc;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter   iter;
GtkListStore *store;
char idx[10];
char jour[10];
char mois[10];
char annee[10];
char nombre_habitants[10];
char nombre_de_conseiller[10];
char municipalite[10];



store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
 	renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nb d'habitants",renderer,"text",ENOMBRE_HABITANTS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nb conseiller",renderer,"text",ENOMBRE_DE_CONSEILLER,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Municipalité",renderer,"text",EMUNICIPALITE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

}
/////////////////////
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f= fopen("election.txt","r");
if (f==NULL)
{
	return;
}
else 
{  f= fopen("election.txt","a+");
	while (fscanf(f,"%s %s %s %s %s %s %s" ,idx,jour,mois,annee,nombre_habitants,nombre_de_conseiller,municipalite)!=EOF)
{
char str[20];
sprintf(str,"%d", id);
if (strcmp(idx,str)==0){
gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,EID,idx,EJOUR,jour,EMOIS,mois,EANNEE,annee,ENOMBRE_HABITANTS,nombre_habitants,ENOMBRE_DE_CONSEILLER,nombre_de_conseiller,EMUNICIPALITE,municipalite,-1);}
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void afficher_election(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter   iter;
GtkListStore *store;
char id[10];
char jour[10];
char mois[10];
char annee[10];
char nombre_habitants[10];
char nombre_de_conseiller[10];
char municipalite[10];


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
 	renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer,"text",EID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jour",renderer,"text",EJOUR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mois",renderer,"text",EMOIS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Annee",renderer,"text",EANNEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nb d'habitants",renderer,"text",ENOMBRE_HABITANTS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nb conseiller",renderer,"text",ENOMBRE_DE_CONSEILLER,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Municipalité",renderer,"text",EMUNICIPALITE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

}
/////////////////////
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f= fopen("election.txt","r");
if (f==NULL)
{
	return;
}
else 
{  f= fopen("election.txt","a+");
	while (fscanf(f,"%s %s %s %s %s %s %s" ,id,jour,mois,annee,nombre_habitants,nombre_de_conseiller,municipalite)!=EOF)

{
gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,EID,id,EJOUR,jour,EMOIS,mois,EANNEE,annee,ENOMBRE_HABITANTS,nombre_habitants,ENOMBRE_DE_CONSEILLER,nombre_de_conseiller,EMUNICIPALITE,municipalite,-1);

}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}










