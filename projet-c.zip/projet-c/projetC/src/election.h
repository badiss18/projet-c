#ifndef ELECTION_C_H_INCLUDED
#define ELECTION_C_H_INCLUDED
#include <gtk/gtk.h>
#include <stdio.h>
typedef struct election
{
int id;
int jour;
int mois;
int annee;
char nombre_habitants[20];
char nombre_de_conseiller[20];
char municipalite[30];

}ele;
int ajouter(char *file,ele elc);

void afficher_election (GtkWidget *liste);
int modifier( char * file , int id , ele nv_elec );
int supprimer (char * file ,int id );
void chercher(int id,GtkWidget *liste);
int verifier(char *file ,int id );

#endif
